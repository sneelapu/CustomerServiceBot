﻿using Microsoft.Azure.CognitiveServices.Language.SpellCheck;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSBot.Services.SpellCheck
{
    public static class SpellCheckExtensions
    {
        public static async Task<string> SpellCheckAsync(this string text, string apiKey)
        {
            if (string.IsNullOrEmpty(text))
            {
                return text;
            }

            var client = new SpellCheckClient(new ApiKeyServiceClientCredentials(apiKey));
            var spellCheckResult = await client.SpellCheckerAsync(text);

            foreach (var flaggedToken in spellCheckResult.FlaggedTokens)
            {
                text = text.Replace(flaggedToken.Token, flaggedToken.Suggestions.FirstOrDefault().Suggestion);
            }
            return text;
        }
    }
}
