﻿using Microsoft.Rest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace CSBot.Services.SpellCheck
{
    public class ApiKeyServiceClientCredentials : ServiceClientCredentials
    {
        string SubscriptionKey { get; set; }
        public ApiKeyServiceClientCredentials(string subscriptionKey)
        {
            SubscriptionKey = subscriptionKey;
        }

        public override Task ProcessHttpRequestAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            request.Headers.Add("Ocp-Apim-Subscription-Key", SubscriptionKey);
            return base.ProcessHttpRequestAsync(request, cancellationToken);
        }
    }
}
