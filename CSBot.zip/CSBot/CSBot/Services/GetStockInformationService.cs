﻿using CSBot.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Text;

namespace CSBot.Services
{
    // API Service to get Access Token and Stock Info
    public class GetStockInformationService
    {
        public IConfiguration Configuration;

        public GetStockInformationService(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public async Task<StockInformationModel> GetStockDataAsync(string materialNumber, string soldTo)
        {
            string clientId = Configuration.GetSection("StockDetails").GetValue<string>("client_id");
            string clientSecret = Configuration.GetSection("StockDetails").GetValue<string>("client_secret");
            string stockInfoURL = $"https://dev-teams-bot-xapi.us-e2.cloudhub.io/api/product";

            var result = await GetAuthTokenAsync();
            try
            {
                HttpClient client = new HttpClient();
                var model = new
                {
                    materialNumber = materialNumber,
                    soldToNumber = soldTo
                };
                var serializedContent = JsonConvert.SerializeObject(model);
                var content = new StringContent(serializedContent, Encoding.UTF8, "application/json");
                content.Headers.Add("client_id", clientId);
                content.Headers.Add("client_secret", clientSecret);

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result.AccessToken);

                HttpResponseMessage response = await client.PostAsync(stockInfoURL, content);

                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content.ReadAsAsync<StockInformationModel>().Result;
                    return res;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public async Task<AuthTokenModel> GetAuthTokenAsync()
        {
            string clientId = Configuration.GetSection("AuthTokenDetails").GetValue<string>("client_id");
            string clientSecret = Configuration.GetSection("AuthTokenDetails").GetValue<string>("client_secret");
            string grantType = Configuration.GetSection("AuthTokenDetails").GetValue<string>("grant_type");
            string scope = Configuration.GetSection("AuthTokenDetails").GetValue<string>("scope");

            string authURL = $"https://login.microsoftonline.com/5d2d3f03-286e-4643-8f5b-10565608e5f8/oauth2/token";

            string stockInfoURL = $"https://dev-teams-bot-xapi.us-e2.cloudhub.io/api/product";

            IDictionary<string, string> parmeters = new Dictionary<string, string>();

            parmeters.Add(new KeyValuePair<string, string>("client_id", clientId));
            parmeters.Add(new KeyValuePair<string, string>("client_secret", clientSecret));
            parmeters.Add(new KeyValuePair<string, string>("grant_type", grantType));
            parmeters.Add(new KeyValuePair<string, string>("scope", scope));

            var content = new FormUrlEncodedContent(parmeters);
            try
            {
                HttpClient client = new HttpClient();
                content.Headers.Clear();
                HttpResponseMessage response = await client.PostAsync(authURL, content);

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsAsync<AuthTokenModel>().Result;
                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}