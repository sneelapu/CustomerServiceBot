﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSBot.Models
{
    public class ConversationData
    {
        // Track whether we have already asked the user for materailnumber
        public bool PromptedUserForMaterialNumber { get; set; } = false;

        // Track whether we have already asked the user for soldto number
        public bool PromptedUserForSoldTo { get; set; } = false;
    }
}
