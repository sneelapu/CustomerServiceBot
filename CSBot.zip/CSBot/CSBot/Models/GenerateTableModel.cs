﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSBot.Models
{
    public class GenerateTableModel
    {
        [JsonProperty("$schema")]
        public string Schema { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("version")]
        public string Version { get; set; }
        [JsonProperty("body")]
        public Body[] Body { get; set; }
    }
    public class Body
    {
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("columns")]
        public Column[] Columns { get; set; }
    }
    public class Column
    {
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("items")]
        public Item[] Items { get; set; }
    }
    public class Item
    {
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("weight", NullValueHandling = NullValueHandling.Ignore)]
        public string Weight { get; set; }
        [JsonProperty("text")]
        public string Text { get; set; }
        [JsonProperty("separator", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Separator { get; set; }
    }
    public enum TypeEnum { TextBlock };
    public enum Weight { Bolder };
}
