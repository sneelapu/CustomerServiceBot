﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSBot.Models
{
    public class UserInfo
    {
        // Model to get User Info
        public string MaterialNumber { get; set; }
        public string SoldToNumber { get; set; }
       
    }
}
