﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSBot.Models
{
    // Model to get Leadtime and Inventory
    public class StockInformationModel
    {
        [JsonProperty("ZBAPI_GET_ZV21N")]
        public ZbapiGetZv21N ZbapiGetZv21N { get; set; }
    }

    public partial class ZbapiGetZv21N
    {
        [JsonProperty("import")]
        public Import Import { get; set; }

        [JsonProperty("export")]
        public Export Export { get; set; }

        [JsonProperty("tables")]
        public Tables Tables { get; set; }
    }

    public partial class Export
    {
        [JsonProperty("leadTime")]
        public string LeadTime { get; set; }

        [JsonProperty("netatp")]
        public long Netatp { get; set; }

        [JsonProperty("plant")]
        public string Plant { get; set; }
    }

    public partial class Import
    {
        [JsonProperty("sold To Customer")]
        public string SoldToCustomer { get; set; }

        [JsonProperty("Material Number")]
        public string MaterialNumber { get; set; }
    }

    public partial class Tables
    {
        [JsonProperty("T_STOCK")]
        public TStock[] TStock { get; set; }
    }
    public partial class TStock
    {
        [JsonProperty("plant")]
        public string Plant { get; set; }

        [JsonProperty("storageLocation")]
        public object StorageLocation { get; set; }

        [JsonProperty("batchNumber")]
        public object BatchNumber { get; set; }

        [JsonProperty("storageLocationDesc")]
        public object StorageLocationDesc { get; set; }

        [JsonProperty("unrestrictedStock1")]
        public string UnrestrictedStock1 { get; set; }

        [JsonProperty("unrestrictedConsignmentStock")]
        public string UnrestrictedConsignmentStock { get; set; }

        [JsonProperty("salesOrder")]
        public string SalesOrder { get; set; }

        [JsonProperty("identifier")]
        public string Identifier { get; set; }

        [JsonProperty("openQuantity")]
        public string OpenQuantity { get; set; }

        [JsonProperty("stockInTransitt")]
        public string StockInTransitt { get; set; }

        [JsonProperty("incomingOrdersQuantity")]
        public string IncomingOrdersQuantity { get; set; }

        [JsonProperty("unrestrictedStock2")]
        public string UnrestrictedStock2 { get; set; }

        [JsonProperty("netDaysSupply")]
        public string NetDaysSupply { get; set; }

        [JsonProperty("dailyorderAverage")]
        public string DailyorderAverage { get; set; }

        [JsonProperty("purchaseOrderQuantity")]
        public string PurchaseOrderQuantity { get; set; }

        [JsonProperty("stoDemand")]
        public string StoDemand { get; set; }

        [JsonProperty("netATP")]
        public string NetAtp { get; set; }

        [JsonProperty("shippableStock")]
        public string ShippableStock { get; set; }

        [JsonProperty("singleCharFlag")]
        public object SingleCharFlag { get; set; }

        [JsonProperty("qualityBlocked")]
        public string QualityBlocked { get; set; }

        [JsonProperty("blockedStock")]
        public string BlockedStock { get; set; }

        [JsonProperty("qualityStock")]
        public string QualityStock { get; set; }

        [JsonProperty("onTheWater")]
        public string OnTheWater { get; set; }

        [JsonProperty("charField8")]
        public string CharField8 { get; set; }

        [JsonProperty("byteField3")]
        public object ByteField3 { get; set; }

        [JsonProperty("plannedDeliverTimeInDays")]
        public long PlannedDeliverTimeInDays { get; set; }

        [JsonProperty("inProduct")]
        public string InProduct { get; set; }

        [JsonProperty("notMoreCloselyDefinedArea")]
        public object NotMoreCloselyDefinedArea { get; set; }

        [JsonProperty("stoSupply")]
        public string StoSupply { get; set; }

        [JsonProperty("leadTime")]
        public string LeadTime { get; set; }
    }
}
