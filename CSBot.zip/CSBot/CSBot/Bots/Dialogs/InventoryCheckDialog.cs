﻿using CSBot.Models;
using CSBot.Services;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CSBot.Bots.Dialogs
{
    // Dialog for Inventory check
    public class InventoryCheckDialog : ComponentDialog
    {
        private IBotServices _botServices;
        public IConfiguration Configuration;
        StockInformationModel details;
        string MaterialNumber;
        public InventoryCheckDialog(IBotServices botServices, IConfiguration configuration) : base(nameof(InventoryCheckDialog))
        {
            _botServices = botServices ?? throw new ArgumentNullException(nameof(botServices));
            Configuration = configuration;
            var waterfallSteps = new WaterfallStep[]
            {
               AskForMaterialNumber,
               ConfirmMaterialNumber,
               SummaryStepAsync
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new AttachmentPrompt(nameof(AttachmentPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            
            if ((bool)stepContext.Result)
            {
                var cardAttachment = await LeadTimeDialog.CreateTable(details);
                await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment), cancellationToken);
                details = null;
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
            else
            {
                details = null;
                await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text($"Okay, Thank you.") });
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }

        private async Task<DialogTurnResult> AskForMaterialNumber(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            MaterialNumber = MainDialog.SharedMaterialNumber as string;
            if (MaterialNumber != null)
            {
                return await stepContext.NextAsync();
            }
            else
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Please provide the Material Number") });
            }
        }

        private async Task<DialogTurnResult> ConfirmMaterialNumber(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (MaterialNumber == null)
            {
                MaterialNumber = (string)stepContext.Result;
            }
            
            GetStockInformationService info = new GetStockInformationService(Configuration);
            details=await info.GetStockDataAsync(MaterialNumber,null);
            if(details!=null)
            {
                MainDialog.SharedMaterialNumber = null;
                MainDialog.SharedSoldTo = null;
                MaterialNumber = null;
                await stepContext.Context.SendActivityAsync($"The available quantity in the inventory is **{details.ZbapiGetZv21N.Export.Netatp}** and default ShipPoint is **{details.ZbapiGetZv21N.Export.Plant}**.");
                return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions { Prompt = MessageFactory.Text($"Would you like to see Plant-wise information?")},cancellationToken);
                             
            }
            else
            {
                await stepContext.Context.SendActivityAsync("Unable to retrieve the inventory data");
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }
    }
}
