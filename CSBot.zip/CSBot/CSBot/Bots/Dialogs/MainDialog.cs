﻿using CSBot.Services;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CSBot.Bots.Dialogs
{
    public class MainDialog : ComponentDialog
    {
        private IBotServices _botServices;
        public IConfiguration Configuration;
        
        public MainDialog(IBotServices botServices, IConfiguration configuration,
           InventoryCheckDialog inventoryCheckDialog, LeadTimeDialog leadtimeCheckDialog) : base(nameof(MainDialog))
        {

            _botServices = botServices ?? throw new ArgumentNullException(nameof(botServices));
            Configuration = configuration;


            // This array defines how the Waterfall will execute.
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(inventoryCheckDialog);
            AddDialog(leadtimeCheckDialog);
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                WaitForUsersMessage,
                BeginDispatchAsync,
                FinalStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        public override async Task<DialogTurnResult> ContinueDialogAsync(DialogContext outerDc, CancellationToken cancellationToken = default)
        {
            if (outerDc.Context.Activity.Type == ActivityTypes.Message)
            {
                var text = outerDc.Context.Activity.Text?.ToLowerInvariant();

                switch (text)
                {
                    case "quit":
                    case "cancel":
                        await outerDc.Context.SendActivityAsync("Quitting the dialog!");
                        return await outerDc.CancelAllDialogsAsync(cancellationToken);

                }
            }

            return await base.ContinueDialogAsync(outerDc, cancellationToken);
        }

        // Step #1
        private async Task<DialogTurnResult> WaitForUsersMessage(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.NextAsync(stepContext.Context.Activity.Text, cancellationToken);

        }
        // Step #2
        private async Task<DialogTurnResult> BeginDispatchAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var usersMessage = (string)stepContext.Result;

            var dispatchResult = await _botServices.Dispatch.RecognizeAsync(stepContext.Context, cancellationToken);
            var topIntent = dispatchResult.GetTopScoringIntent();

            return await DispatchToTopIntentAsync(stepContext, topIntent.intent, dispatchResult, cancellationToken);
        }

        //Checks for topintent and processes the appropriate dispatch method
        public async Task<DialogTurnResult> DispatchToTopIntentAsync(WaterfallStepContext stepContext, string intent, RecognizerResult dispatchResult, CancellationToken cancellationToken)
        {
            switch (intent)
            {
                case "l_cs-bot-luis-app-dev":
                    return await ProcessLuisAsync(stepContext, dispatchResult.Properties["luisResult"] as LuisResult, cancellationToken);

                case "q_csbot-qna-kb":
                    return await ProcessQnAAsync(stepContext, cancellationToken);
                default:
                    await stepContext.Context.SendActivityAsync("Sorry! I am unable to help with that at the moment.");
                    return await stepContext.NextAsync(null, cancellationToken);
            }

        }

        public async Task<DialogTurnResult> ProcessLuisAsync(WaterfallStepContext stepContext, LuisResult luisResult, CancellationToken cancellationToken)
        {
             string _materialNumber = null, _soldTo = null;

        var result = luisResult.ConnectedServiceResult;
            var entities = result.Entities;
            foreach (var entity in entities)
            {
                if (entity.Type == "materialnumber")
                {
                    _materialNumber = entity.Entity.Replace(" - ", "-");
                    SharedMaterialNumber = _materialNumber;
                }
                if (entity.Type == "soldto")
                {
                    _soldTo = entity.Entity.ToUpper();
                    SharedSoldTo = _soldTo;
                }
            }

            var topIntent = result.TopScoringIntent.Intent;
            switch (topIntent)
            {
                case "Inquiry_Inventory":
                    _materialNumber = null;
                    _soldTo = null;
                        return await stepContext.BeginDialogAsync(nameof(InventoryCheckDialog), null, cancellationToken);
                   
                    
                case "Inquiry_LeadTime":
                    _materialNumber = null;
                    _soldTo = null;
                    return await stepContext.BeginDialogAsync(nameof(LeadTimeDialog), cancellationToken);
                    //if (!string.IsNullOrEmpty(_materialNumber) && !string.IsNullOrEmpty(_soldTo))
                    //{

                    //    GetStockInformationService info = new GetStockInformationService(Configuration);
                    //    var details = await info.GetStockDataAsync(_materialNumber, _soldTo);
                    //    if (details != null)
                    //    {
                    //        int resp;
                    //        int.TryParse(details.ZbapiGetZv21N.Export.LeadTime, out resp);
                    //        var cardAttachment = await LeadTimeDialog.CreateTable(details);
                    //        await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text($"The lead time for provided information is **{resp} days** and the available inventory is: **{details.ZbapiGetZv21N.Export.Netatp}** ") });
                    //        await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment), cancellationToken);
                    //        MainDialog.SharedSoldTo = null;
                    //        MainDialog.SharedMaterialNumber = null;
                    //        _materialNumber = null;
                    //        _soldTo = null;
                    //        return await stepContext.EndDialogAsync(null, cancellationToken);
                    //    }
                    //    //await stepContext.Context.SendActivityAsync(MessageFactory.Text($"The leadtime for the materail is 22 days "), cancellationToken);
                    //}
                    //else if (!string.IsNullOrEmpty(_materialNumber))
                    //{

                    //    return await stepContext.BeginDialogAsync(nameof(LeadTimeDialog), cancellationToken);
                    //}
                    //else if (!string.IsNullOrEmpty(_soldTo))
                    //{

                    //    return await stepContext.BeginDialogAsync(nameof(LeadTimeDialog), cancellationToken);
                    //}
                    //else
                    //{
                    //    return await stepContext.BeginDialogAsync(nameof(LeadTimeDialog), cancellationToken);
                    //}

                    break;
                default:
                    await stepContext.Context.SendActivityAsync("Sorry! I am unable to understand that");
                    break;
            }

            return await stepContext.NextAsync(null, cancellationToken);
        }

        public static object SharedMaterialNumber;
        public static object SharedSoldTo;

        private async Task<DialogTurnResult> ProcessQnAAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var answers = await _botServices.QnA.GetAnswersAsync(stepContext.Context);

            if (answers.Any())
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text(answers.First().Answer), cancellationToken);
            }
            else
            {
                await stepContext.Context.SendActivityAsync("Sorry! I am unable to answer that at the moment.");
            }
            return await stepContext.NextAsync(null, cancellationToken);
        }

        // Step #3
        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.EndDialogAsync(null, cancellationToken);
        }

    }

}
