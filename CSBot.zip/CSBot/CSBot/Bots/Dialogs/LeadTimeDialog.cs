﻿using CSBot.Models;
using CSBot.Services;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CSBot.Bots.Dialogs
{
    // Dialog for Leadtime
    public class LeadTimeDialog : ComponentDialog
    {
        private IBotServices _botServices;
        public IConfiguration Configuration;
        string MaterialNumber, SoldTo;
        StockInformationModel details;
        public LeadTimeDialog(IBotServices botServices, IConfiguration configuration) : base(nameof(LeadTimeDialog))
        {
            _botServices = botServices ?? throw new ArgumentNullException(nameof(botServices));
            Configuration = configuration;
            var waterfallSteps = new WaterfallStep[]
            {
                AskForMaterialNumber,
                AskForSoldtoNumber,
                ConfirmSoldtoNumber,
                SummaryStep
                
            };

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            InitialDialogId = nameof(WaterfallDialog);
        }
        private async Task<DialogTurnResult> AskForMaterialNumber(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            MaterialNumber = MainDialog.SharedMaterialNumber as string;
            if (MaterialNumber != null)
            {
                return await stepContext.NextAsync();
            }
            else
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Please provide the Material Number") });
            }
           
        }
        public async Task<DialogTurnResult> AskForSoldtoNumber(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            SoldTo = (string)MainDialog.SharedSoldTo;
            if (MaterialNumber == null)
            {
                MaterialNumber = (string)stepContext.Result;
            }

            if (SoldTo != null)
            {
                return await stepContext.NextAsync();
            }
            else
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text($" Please provide the Sold-To number") });
            }

        }
        public async Task<DialogTurnResult> ConfirmSoldtoNumber(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (SoldTo == null)
            {
                SoldTo = (string)stepContext.Result;
            }

           GetStockInformationService info = new GetStockInformationService(Configuration);
            details = await info.GetStockDataAsync(MaterialNumber, SoldTo.ToUpper());
            if (details != null)
            {
                MainDialog.SharedMaterialNumber = null;
                MainDialog.SharedSoldTo = null;
                MaterialNumber = null;
                SoldTo = null;
                int resp;
                int.TryParse(details.ZbapiGetZv21N.Export.LeadTime, out resp);
                await stepContext.Context.SendActivityAsync($"Lead time for the provided information is **{resp} days** with available inventory **{details.ZbapiGetZv21N.Export.Netatp}** and the default ShipPoint is **{details.ZbapiGetZv21N.Export.Plant}**. ");
                return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
                {
                    Prompt = MessageFactory.Text($"Would you like to see Plant-wise information?")}, cancellationToken);

            }
            else
            {
                await stepContext.Context.SendActivityAsync("Unable to retrieve Leadtime information for provided details");
                MainDialog.SharedMaterialNumber = null;
                MainDialog.SharedSoldTo = null;
                MaterialNumber = null;
                SoldTo = null;
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }

        }

        private async Task<DialogTurnResult> SummaryStep(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            
            if ((bool)stepContext.Result)
            {
                var cardAttachment = await CreateTable(details);
                await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment), cancellationToken);
                details = null;
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
            else
            {
                details = null;
                await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text($"Okay, Thank you.") });
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }

        public async static Task<Attachment> CreateTable(StockInformationModel stockInformation)
        {
            try
            {
                List<Item> PlantItems = new List<Item>();
                Item item = new Item
                {
                    Type = "TextBlock",
                    Weight = "Bolder",
                    Text = "Plant Name"
                };
                PlantItems.Add(item);
                foreach (var stock in stockInformation.ZbapiGetZv21N.Tables.TStock)
                {
                    Item nextItem = new Item
                    {
                        Type = "TextBlock",
                        Separator = true,
                        Weight = "Bolder",
                        Text = stock.Plant??null
                    };
                    PlantItems.Add(nextItem);
                }
                List<Item> NetATPItems = new List<Item>();
                Item ATPitem = new Item
                {
                    Type = "TextBlock",
                    Weight = "Bolder",
                    Text = "Net ATP"
                };
                NetATPItems.Add(ATPitem);
                foreach (var stock in stockInformation.ZbapiGetZv21N.Tables.TStock)
                {
                    Item nextItem = new Item
                    {
                        Type = "TextBlock",
                        Separator = true,
                        Weight = "Bolder",
                        Text = stock.NetAtp.ToString()
                    };
                    NetATPItems.Add(nextItem);
                }
                List<Item> LeadTimeItems = new List<Item>();
                Item LeadTimeitem = new Item
                {
                    Type = "TextBlock",
                    Weight = "Bolder",
                    Text = "Lead Time"
                };
                LeadTimeItems.Add(LeadTimeitem);
                foreach (var stock in stockInformation.ZbapiGetZv21N.Tables.TStock)
                {
                    Item nextItem = new Item
                    {
                        Type = "TextBlock",
                        Separator = true,
                        Weight = "Bolder",
                        Text = stock.LeadTime.ToString()
                    };
                    LeadTimeItems.Add(nextItem);
                }
                List<Column> columns = new List<Column>();
                Column col = new Column
                {
                    Type = "Column",
                    Items = PlantItems.ToArray()
                };
                Column col1 = new Column
                {
                    Type = "Column",
                    Items = NetATPItems.ToArray()
                };
                Column col2 = new Column
                {
                    Type = "Column",
                    Items = LeadTimeItems.ToArray()
                };
                columns.Add(col);
                columns.Add(col1);
                columns.Add(col2);
                List<Body> details = new List<Body>();
                Body body = new Body
                {
                    Type = "ColumnSet",
                    Columns = columns.ToArray()
                };
                List<Body> bodies = new List<Body>();
                bodies.Add(body);
                var data = new GenerateTableModel
                {
                    Schema = "http://adaptivecards.io/schemas/adaptive-card.json",
                    Type = "AdaptiveCard",
                    Version = "1.0",
                    Body = bodies.ToArray()
                };
                var res = JsonConvert.SerializeObject(data);
                var adaptiveCardAttachment = new Attachment()
                {
                    ContentType = "application/vnd.microsoft.card.adaptive",
                    Content = JsonConvert.DeserializeObject(res),
                };
                return adaptiveCardAttachment;
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }
}
