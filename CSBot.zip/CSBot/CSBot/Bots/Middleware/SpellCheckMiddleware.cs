﻿using CSBot.Services.SpellCheck;
using Microsoft.Bot.Builder;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CSBot.Bots.Middleware
{
    public class SpellCheckMiddleware : IMiddleware
    {
        public SpellCheckMiddleware(IConfiguration configuration)
        {
            ApiKey = configuration.GetValue<string>("SpellCheckKey");
        }

        public string ApiKey { get; }

        public async Task OnTurnAsync(ITurnContext turnContext, NextDelegate next, CancellationToken cancellationToken = default)
        {
            turnContext.Activity.Text = await turnContext.Activity.Text.SpellCheckAsync(ApiKey);

            await next(cancellationToken);
        }
    }
}
